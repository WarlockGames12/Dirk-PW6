-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 17 jan 2020 om 10:09
-- Serverversie: 10.3.15-MariaDB
-- PHP-versie: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buurtzorg`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tb_users`
--

CREATE TABLE `tb_users` (
  `uuid` varchar(40) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `role` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `hash` varchar(200) NOT NULL,
  `hash_date` datetime DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `tb_users`
--

INSERT INTO `tb_users` (`uuid`, `username`, `password`, `email`, `role`, `status`, `hash`, `hash_date`, `timestamp`) VALUES
('21a91163-1aed-4e34-aac9-9b821809d01e', 'eriksteens', '$2y$10$a2vhKYk1kvnTEpw8cKpIWOFqAYSd8FcdMr.9MfQMMdXYjntP6jCu2', 'erik@erik.nl', '1,5', 1, '59d5f7ab4d1f8ca995bd8ce38aff8df96a2c5c6adf31d082d3811c6b99ed927e', '2019-12-04 21:35:18', '2019-12-01 12:21:27'),
('786d8674-584a-476e-8791-77922b07894f', 'hayley', '$2y$10$O0ktxAluErlaFrRvggs0/.iRhAjWrSjJXpM.aA0JwT2AD7b2cf1qa', 'hayley@williams.com', '1', 1, '5044ae72796bda740863bb3489f05d37ded9a6d50709bb98d54a1cca162215af', '2019-12-10 06:17:17', '2019-12-03 20:40:06'),
('dea5c3b7-12e9-4f30-b96f-7e29ad8e72a4', 'Warlock', '$2y$10$V23OK7eF/4Ow5JnAaX6azuKcLO4ZmcBoXNW32foWwo.Z6HIfDFv.m', 'fpweeyou@gmail.com', '3', 0, 'baaeefcd2f3ae0df7491aec4b184819c3e0a15b78a34ae912a94dbd4e87c5b6a', '2019-12-17 09:57:58', '2019-12-16 08:57:58');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `tb_vacature`
--

CREATE TABLE `tb_vacature` (
  `id` int(11) NOT NULL,
  `vacature` varchar(50) NOT NULL,
  `Info` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `tb_vacature`
--

INSERT INTO `tb_vacature` (`id`, `vacature`, `Info`) VALUES
(1, 'Dokter', 'In ieder geval heeft moet het iemand zijn die veel ervaring met helpen om te herkennen wat de patient heeft. \r\n\r\nU moet teminste 5 jaar ervaring nodig om als dokter te solliciteren.'),
(2, 'Balie medewerker', 'Wij hebben iemand bij de balie nodig zodat als er iemand belt dat zij meteen opnemen en vraagt wat er aan de hand is met de patient. \r\n\r\n'),
(3, 'Assistent Dokter', 'Zij helpen de dokter om alles voor te bereiden.\r\n\r\nU kan 1200 euro per week verdienen om bij ons te werken als een assistent'),
(4, 'congierge ', 'Wij hebben iemand nodig die ons hoofdkwatier kan schoonmaken.\r\n\r\nU krijgt 300 euro per week als salaris.'),
(5, 'Klantenservice', 'Wij hebben iemand nodig die mensen kunnen helpen die geen idee hebben wat ze moeten doen. ');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`uuid`),
  ADD KEY `username` (`username`),
  ADD KEY `password` (`password`);

--
-- Indexen voor tabel `tb_vacature`
--
ALTER TABLE `tb_vacature`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `tb_vacature`
--
ALTER TABLE `tb_vacature`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
