<?php


class goedkeuringPage{
    
    public function getHtml(){
        //if($_SESSION['user']['role'] != 4) { return; }
        if(defined('ACTION')) {			// process the action obtained is existent
				switch(ACTION) {
					// get html for the required action
					case "goedkeuren"		  : return $this->goedkeuren(); break;
                    case "verwijderen"        : return $this->verwijderen(); break;
				}
           } else { // no ACTION so normal page (= de upper page, het overzicht => alle data uitspuwen)
				$table 	= $this->overviewPage();		// get users from database in tableform
				//$button = $this->addButton("/create", "Solliciteren");	// add "/add" button. This is ACTION button
				// first show button, then table
                $html = "";
                //$html .= $button ."<br />";
				$html .= $table;
				return $html;
			}
		}

		// show button with the PAGE $p_sAction and the tekst $p_sActionText
        // deze button volgt gewoon een link => geen NAME nodig, enkel een URL
		private function addButton($p_sAction, $p_sActionText) {
			// calculate url and trim all parameters [0..9]
            $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
			// create new link with PARAM for processing in new page request
			$url = $url . $p_sAction;
			$button = "<button style='margin-top: 10px;' onclick='location.href = \"$url\";'>$p_sActionText</button>";
			return $button;
		}

            
		// deze functie geeft de overview page weer (als er géén ACTIOn in de URL staat)
		private function overviewPage(){
			// execute a query and return the result
			$sql='SELECT * FROM `tb_sollicitanten` ORDER BY status,volledigenaam';
            $result = $this->createTable(Database::getData($sql));

			//TODO: generate JSON output like this for webservices in future
			/*
				$data = Database::getData($sql);
				$json = Database::jsonParse($data);
				$array = Database::jsonParse($json);

				echo "<br />result: ";  print_r(Database::getData($sql));
	            echo "<br /><br />json :" . $json;
	            echo "<br /><br />array :"; print_r($array);
			*/

			return $result;
		} // end function getData()

		private function createTable($p_aDbResult){ // create html table from dbase result
			
            $table = "";
            
            $imgGoedkeuren  = "<img src='".ICONS_PATH."correct.png' style='width: 24px; height: 24px;'/>";
			$imgVerwijderen = "<img src='".ICONS_PATH."cancel.png' style='width: 24px; height: 24px;' />";
			$table .= "<table border='1'>";
				$table .= "	<th>uuid</th>
                            <th>Vacaturenaam</th>
							<th>Volledige naam</th>
							<th>E-mail</th>
                            <th>bericht</th>
                            <th>status</th>";
				// now process every row in the $dbResult array and convert into table
				foreach ($p_aDbResult as $row){
					$table .= "<tr>";
						foreach ($row as $colName=>$colValue) {
                            
							// check of het gaat om vacatureID
                            if ( $colName == "vacature_id" ){
                                $sql = "SELECT vacature FROM tb_vacature WHERE id=". $colValue;
                                $outputSQL = Database::getData($sql);
                                
                                // hier willen we vacaturenaam ophalen aan de hand van het id
                                $table .= "<td>" . $outputSQL['0']["vacature"] . "</td>";
                            } else {
                                $table .= "<td>" . $colValue . "</td>";
                            }
						}
                    
	                    // calculate url and trim all parameters [0..9]
	                    $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
						// create button for "goedkeuren"
						$table 	.= "<td><a href="
								. $url 							// current menu
								. "/goedkeuren/" . $row["id"] 	// add ACTION and PARAM to the link
								. ">$imgGoedkeuren</a></td>";			// link to edit icon
                        // create button for "verwijderen"
						$table 	.= "<td><a href="
								. $url 							// current menu
								. "/verwijderen/" . $row["id"] 	// add ACTION and PARAM to the link
								. ">$imgVerwijderen</a></td>";			// link to edit icon
					$table .= "</tr>";
					
				} // foreach
			$table .= "</table>";
			return $table;
		} //function

	
		// deze functie geeft de pagina weer om te solliciteren op basis van de URL, ACTION = "sollicitatie"
		private function goedkeuren() {
			
            // de ID van de gekozen sollicitatie, zit mee in de URL, die kunnen we afvangen met de constante PARAM
            $sollicitatieID = PARAM;
            
            // delete query
            $sql = 'UPDATE `tb_sollicitanten` SET `status`="1" WHERE id='.$sollicitatieID;
            $result = Database::getData($sql);
            
            // na verwijderen terug redirecten naar de overzichtspagina
            header("location: ../../stemmen");
                   
		} // function details
      
        private function verwijderen(){
            
            // de ID van de gekozen sollicitatie, zit mee in de URL, die kunnen we afvangen met de constante PARAM
            $sollicitatieID = PARAM;
            
            // delete query
            $sql = 'DELETE FROM `tb_sollicitanten` WHERE id='.$sollicitatieID;
            $result = Database::getData($sql);
            
            // na verwijderen terug redirecten naar de overzichtspagina
            header("location: ../../goedkeuring");
            
        }
    }
    


?>