<?php
/*************************************************************
	Pagebuilder framework application
	Learning application for VISTA AO JL2 P5
	Created 2019 by e.steens
*************************************************************/
/*
	Contains details of page information
	returns the built html
	Class Name convention: <pagename>Page
	Must contain iPage interface implementation ie getHtml()
	Called by content.inc.php
*/
class HomePage {
		public function getHtml() {
			$html = <<<HTML
            <h1>Welkom bij Stichting Buurtzorg Nederland</h1>
            <h2>Waar kunnen wij u mee helpen?</h2>
            <p>Wij kunnen u helpen om een baan te zoeken of onze hulp in te schakelen als er iets aan de hand is met u welzijn of gezondheid...</p>
HTML;
            return $html;
		}
	}