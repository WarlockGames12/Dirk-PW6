<?php
 
class vacaturesmakenPage extends Core implements iPage{
    public function getHtml(){
       
            //VOORBEELD
            //if($_SESSION['user']['role'] != 3) { return; }
        
			if(defined('ACTION')) {			// process the action obtained is existent
				switch(ACTION) {
					// get html for the required action
					case "create"	: return $this->create(); break;
					case "read"		: return $this->read(); break;
					case "update"	: return $this->update();break;
					case "delete"	: return $this->delete();
				}
			} else { // no ACTION so normal page
				$table 	= $this->getData();		// get users from database in tableform
				$button = $this->addButton("/create", "Toevoegen");	// add "/add" button. This is ACTION button
				// first show button, then table
				$html = $button . "<br />" . $table;
				return $html;
			}
		}

		// show button with the PAGE $p_sAction and the tekst $p_sActionText
		private function addButton($p_sAction, $p_sActionText) {
			// calculate url and trim all parameters [0..9]
            $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
			// create new link with PARAM for processing in new page request
			$url = $url . $p_sAction;
			$button = "<button onclick='location.href = \"$url\";'>$p_sActionText</button>";
			return $button;
		}

        
		private function getData(){
			// execute a query and return the result
			$sql='SELECT * FROM `tb_vacature` ORDER BY id';
            $result = $this->createTable(Database::getData($sql));

			//TODO: generate JSON output like this for webservices in future
			/*
				$data = Database::getData($sql);
				$json = Database::jsonParse($data);
				$array = Database::jsonParse($json);

				echo "<br />result: ";  print_r(Database::getData($sql));
	            echo "<br /><br />json :" . $json;
	            echo "<br /><br />array :"; print_r($array);
			*/

			return $result;
		} // end function getData()

		private function createTable($p_aDbResult){ // create html table from dbase result
			$imageDel  = "<img src='".ICONS_PATH."cancel.png' />";
            $imageUp   = "<img src='".ICONS_PATH."update.png'/>";
            $imageRead = "<img src='".ICONS_PATH."book.png'/>";
			$table = "<table border='1'>";
				$table .= "	<th>uuid</th>
							<th>vacature</th>
                            <th>Informatie</th>";
				// now process every row in the $dbResult array and convert into table
				foreach ($p_aDbResult as $row){
					$table .= "<tr>";
						foreach ($row as $col) {
							$table .= "<td>" . $col . "</td>";
						}
	                    // calculate url and trim all parameters [0..9]
	                    $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
						// create new link with parameter (== edit user link!)
						$table 	.= "<td><a href="
								. $url 							// current menu
								. "/read/" . $row["id"] 	// add ACTION and PARAM to the link
								. ">$imageRead</a></td>";			// link to edit icon
                            
						//create new link with parameter (== delete user)
						$table 	.= "<td><a href="
								. $url 							// current menu
								. "/delete/" . $row["id"] 	// add ACTION and PARAM to the link
								. ">$imageDel</a></td>";			// link to delete icon
						// create new link with parameter (== update)
						$table 	.= "<td><a href="
								. $url 							// current menu
								. "/update/" . $row["id"] 	// add ACTION and PARAM to the link
								. ">$imageUp</a></td>";			// link to delete icon
					$table .= "</tr>";
					
				} // foreach
			$table .= "</table>";
			return $table;
		} //function

		// [C]rud action
		// based on sent form 'frmAddUser' fields
		private function create() {
			// use variabel field  from form for processing -->
			if(isset($_POST['frmAddVacature'])) {
				return $this->processFormAddVacature();
			} // ifisset
			else {
				return $this->addForm();
			} //else
		}

		private function addForm() { // processed in $this->processFormAddUser()
			$url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]"); 	// strip not required info
			// heredoc statement. Everything between 2 HTML labels is put into $html
			$html = <<<HTML
				<fieldset>
					<legend>Voeg een nieuwe gebruiker toe</legend>
						<form action="$url" enctype="multipart/formdata" method="post">
							<label>Vacature</label>
							<input type="text" name="vacature" id="" value="" placeholder="vacature" />

							<label>Info</label>
							<input type="textarea" name="Info" id="" value="" placeholder="info" />

							<label></label>
							<!-- add hidden field for processing -->
							<input type="hidden" name="frmAddVacature" value="frmAddVacature" />
							<input type="submit" name="submit" value="Voeg toe" />
						</form>
				</fieldset>
HTML;
			return $html;
		} // function

		private function processFormAddVacature() {
			$hash 		= $this->createHash(); // in code
			$id 		= $this->createUuid(); // in code
			$hashDate 	= $this->createHashDate(); // in core
			// get transfered datafields from form "$this->addForm()"
	
			$vacature 	= $_POST['vacature'];
			$info		= $_POST['Info'];
			// create insert query with all info above
			$sql = "INSERT INTO tb_vacature (vacature, Info) VALUES ('$vacature', '$info')";

			Database::getData($sql);
			/*
				echo "<br />";
				echo $hash . "<br />";
				echo $uuid . "<br />";
				echo $hashDate . "<br />";
			*/
			return "Vacature is toegevoegd.";
		} //function

		// c[R]ud action
		private function read() {
			// get and present information from the user with uuid in PARAM
			$button = $this->addButton("/../../vacaturesmaken", "Terug");	
			// first show button, then table
			
            $id = PARAM;
            $sql="SELECT * FROM `tb_vacature` WHERE id = '$id'";
            $result = $this->createTable(Database::getDATA($sql));
            return $button . $result;
            
                   
		} // function details

		//cr[U]d action
		private function update() {
			// present form with all user information editable and process
			$button = $this->addButton("/../../vacaturesmaken", "Terug");	
			// first show button, then table

			if(isset($_POST['frmUpdateVacature'])) {
				return $this->processFormUpdateVacature();
			} // ifisset
			else {
				return $this->updateForm();
			} //else    
		}
        
        private function updateForm() { // processed in $this->processFormAddUser()
			$url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]"); 	// strip not required info
			// heredoc statement. Everything between 2 HTML labels is put into $html
            $id = PARAM;
            $sql='SELECT vacature, Info FROM `tb_vacature` WHERE id = ?';
            $aData = array(PARAM);
            $result = Database::getData($sql, $aData );
            $vacature = $result[0]['vacature'];
            $info = $result[0]['Info'];
			$html = <<<HTML
				<fieldset>
					<legend>Update deze Vacature</legend>
						<form action="$url/$id" enctype="multipart/formdata" method="post">
							<label>Vacature</label>
							<input type="text" name="vacature" id="" value="$vacature" placeholder="vacature" />

							<label>Info</label>
							<input type="textarea" name="Info" id="$info" value="$info" placeholder="info" />

							<label></label>
							<!-- add hidden field for processing -->
							<input type="hidden" name="frmUpdateUser" value="frmUpdateUser" />
							<input type="submit" name="submit" value="Update" />
						</form>
				</fieldset>
HTML;
			return $html;
		} // function

		private function processFormUpdateVacature() {
			$vacature 	= $_POST['vacature'];
			$info		= $_POST['Info'];
			// create insert query with all info above
			//$sql = "UPDATE tb_users (username, password, email, role, status) VALUES ('$username', '$password', '$email', '$role', '$status') WHERE uuid = ?";
            $sql = "UPDATE tb_vacature SET vacature = '$vacature', Info = '$info' WHERE id = ?";
            $aData = array(PARAM);
			Database::getData($sql, $aData);
            var_dump ($sql); die;
			/*
				echo "<br />";
				echo $hash . "<br />";
				echo $uuid . "<br />";
				echo $hashDate . "<br />";
			*/
			return "Vacature is geupdated.";
		} //function


		//crd[D] action
		private function delete() {
			// remove selected record based om uuid in PARAM
			$sql='DELETE FROM tb_vacature WHERE id="' . PARAM. '"';		
            $result = Database::getData($sql);
			$button = $this->addButton("/../../vacaturesmaken", "Terug");	// add "/add" button. This is ACTION button
			// first show button, then table

			return $button ."<br>Deze vacature is verwijderd " . PARAM . "We will execute order 66, goodbye";
		}
	}// class gebruikerPage
    


?>