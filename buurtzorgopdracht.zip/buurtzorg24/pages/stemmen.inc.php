<?php

class stemmenPage{
   
     public function getHtml() {
			
           //if($_SESSION['user']['role'] != 4) { return; }
           if(defined('ACTION')) {		// process the action obtained is existent
				switch(ACTION) {
					// get html for the required action
                    case "sollicitanten"          : return $this->sollicitanten(); break;
                    case "voteup"                 : return $this->voteup(); break;
                    case "votedown"               : return $this->votedown(); break;
				}
           } else { // no ACTION so normal page (= de upper page, het overzicht => alle data uitspuwen)
				$table 	= $this->overviewPage();		// get users from database in tableform
				//$button = $this->addButton("/create", "Solliciteren");	// add "/add" button. This is ACTION button
				// first show button, then table
                $html = "";
                //$html .= $button ."<br />";
				$html .= $table;
				return $html;
			}
		}

		// show button with the PAGE $p_sAction and the tekst $p_sActionText
        // deze button volgt gewoon een link => geen NAME nodig, enkel een URL
		private function addButton($p_sAction, $p_sActionText) {
			// calculate url and trim all parameters [0..9]
            $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
			// create new link with PARAM for processing in new page request
			$url = $url . $p_sAction;
			$button = "<button style='margin-top: 10px;' onclick='location.href = \"$url\";'>$p_sActionText</button>";
			return $button;
		}

            
		// deze functie geeft de overview page weer (als er géén ACTIOn in de URL staat)
		private function overviewPage(){
			// execute a query and return the result
			$sql='SELECT * FROM `tb_vacature`';
            $result = $this->createVacaturesOverviewTable(Database::getData($sql));

			return $result;
		} // end function getData()

		private function createVacaturesOverviewTable($p_aDbResult){ // create html table from dbase result
			$image = "<img src='".ICONS_PATH."noun_information user_24px.png' />";
			$table = "<table border='1'>";
				$table .= "	<th>uuid</th>
							<th>vacature</th>
							<th>sollicitanten<br>(goedgekeurd)</th>";
				// now process every row in the $dbResult array and convert into table
				foreach ($p_aDbResult as $row){
					$table .= "<tr>";
                        $vacatureID=0;
						foreach ($row as $colName => $colValue) {
							// gehele tekst van vacature niet meer weergeven
                            if ( $colName!="Info" AND $colName !="ingevuld") {
                                $table .= "<td>" . $colValue . "</td>";
                            }
                            if ( $colName=="id") {
                                $vacatureID = $colValue;
                            }
						}
                        
                        // wat we wel willen weergeven is het aantal goedgekeurde sollicitanten bij deze vacature.
                        $sql='SELECT * FROM `tb_sollicitanten` WHERE vacature_id='.$vacatureID.' AND status = 1';
                        $countSollicitanten = Database::getData($sql);
                        //nl2br(var_dump($countSollicitanten));
                        $table  .= "<td>". count($countSollicitanten) ."</td>";
	                    // calculate url and trim all parameters [0..9]
	                    $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
						// create new link with parameter (== edit user link!)
						$table 	.= "<td><a href="
								. $url 							// current menu
								. "/sollicitanten/" . $row["id"]// add ACTION and PARAM to the link
								. ">$image</a></td>";			// link to edit icon
					$table .= "</tr>";
					
				} // foreach
			$table .= "</table>";
			return $table;
		} //function

    
    
	   private function sollicitanten() {
           
            // vacature ID
            $vacatureID = PARAM;
           
            // execute a query and return the result
			$sql='SELECT * FROM `tb_sollicitanten` WHERE vacature_id = '. $vacatureID .' AND status = 1';
            $result = $this->createSollicitatiesTable(Database::getData($sql));

			return $result;
           
       }
    
    private function createSollicitatiesTable($p_aDbResult){ // create html table from dbase result
			
            // vacature info ophalen
            $vacatureID = PARAM;
            $sqlVacature = "SELECT * FROM tb_vacature WHERE id = ". $vacatureID;
            $resultVacature = Database::getData($sqlVacature);
            $vacatureIngevuld = $resultVacature[0]['ingevuld'];
        
        
            $imageUp = "<img src='../../".ICONS_PATH."good.png' />";
			$imageDown = "<img src='../../".ICONS_PATH."bad.png' />";
            $table = "";
        
            if ( $vacatureIngevuld == 1) {
                $table .= "Deze vacature is al ingevuld, er kan niet meer gestemd worden.";
            }    
        
			$table .= "<table border='1'>";
				$table .= "	<th>id</th>
							<th>Naam sollicitant</th>
							<th>E-mailadres</th>
							<th>Motivatie</th>";
				// now process every row in the $dbResult array and convert into table
				foreach ($p_aDbResult as $row){
					$table .= "<tr>";
                        $vacatureID=0;
						foreach ($row as $colName => $colValue) {
							if ( $colName == "vacature_id" OR $colName == "status" ){
                               // dan geven we niets weer 
                            } else {
                                // alle andere velden geven we wel weer
                                $table .= "<td>" . $colValue . "</td>";
                            }
						}
                        
                        
                        // calculate url and trim all parameters [0..9]
	                    $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
                        $url = str_replace ( "/sollicitanten","",$url);
					    
                        // indien sollicitatie al ingevuld is, moet er natuurlijk niet meer gestemd worden	
                        if ($vacatureIngevuld==0) {
                            // create new link with parameter (== edit user link!)
                            $table 	.= "<td><a href="
                                    . $url 							// current menu
                                    . "/voteup/" . $row["id"]// add ACTION and PARAM to the link
                                    . ">$imageUp</a></td>"			// link to edit icon
                                    . "<td><a href="
                                    . $url 							// current menu
                                    . "/votedown/" . $row["id"]// add ACTION and PARAM to the link
                                    . ">$imageDown</a></td>";			// link to edit icon
                        }
                    
					$table .= "</tr>";
					
				} // foreach
			$table .= "</table>";
			return $table;
		} //function
    
    
    /**
     * Bij een UP-vote (duimpje omhoog) worden automatisch alle ander sollicitaties verwijderd en deze goedgekeurd => er wordt gemaild naar admin
     * Bij een DOWN-vote (duimpje omlaag) wordt deze sollicitatie gewoon verwijderd.
     */
    
    private function voteup() {
        
        // goedkeuren van deze sollicitatie, en de rest verwijderen...
        
        // sollicitatieID via URL mee
        $sollicitatieID = PARAM;
        
        // informatie ophalen rond de goedgekeurde sollicitatie
        $sqlSollicitatie='SELECT * FROM `tb_sollicitanten` WHERE id = '. $sollicitatieID;
        $resultSollicitatie = Database::getData($sqlSollicitatie);
        
        // vacatureID
        $vacatureID = $resultSollicitatie[0]['vacature_id'];
        
        // informatie ophalen rond de vacature
        $sqlVacature ='SELECT * FROM `tb_vacature` WHERE id = '. $vacatureID;
        $resultVacature = Database::getData($sqlVacature);
        
        // vacature titel
        $vacatureTitel = $resultVacature[0]["vacature"];
        
        // update query dat vacature ingevuld is
        $sqlUpdate = "UPDATE `tb_vacature` SET `ingevuld`='1' WHERE id =". $vacatureID;
        $resultUpdate = Database::getData($sqlUpdate);
        
        // verwijder alle andere sollicitatie voor deze vacature: we gaan alle sollicitatie op deze vacature_id verwijderen, BEHALVE deze sollicitatie zelf
        $sqlDelete = "DELETE FROM `tb_sollicitanten` WHERE vacature_id =". $vacatureID ." AND id !=". $sollicitatieID;
        $resultDelete = Database::getData($sqlDelete);
        
        // mail naar admin
        $to = "admin@buurtzorg24.nl";
        $subject = "Goedgekeurde sollicitatie bij vacature ". $vacatureTitel;
        $message = "Er werd voor de bovenstaande vacature een sollicitatie goedgekeurd. De andere sollicitaties werden dus verwijderd.";
        //mail ( $to , $subject , $message );
        
        // gezien mail niet werkt, output ook even echo'en
        return "Aan: ". $to ."<br>Onderwerp:". $subject."<br>Message: ". $message;
        
        
    }
    
}

?>