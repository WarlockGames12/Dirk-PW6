 <?php
/*************************************************************
	Pagebuilder framework application
	Learning application for VISTA AO JL2 P5
	Created 2019 by e.steens
*************************************************************/
/*
	Contains details of page information
	returns the built html
	Class Name convention: <pagename>Page
	Must contain iPage interface implementation ie getHtml()
	Called by content.inc.php
*/

        class vacaturePage extends Core implements iPage {

       public function getHtml() {
			
           
           if(defined('ACTION')) {			// process the action obtained is existent
				switch(ACTION) {
					// get html for the required action
					case "detail-vacature"	: return $this->detailVacature(); break;
					case "sollicitatie"		: return $this->sollicitatieFormulier(); break;
				}
           } else { // no ACTION so normal page (= de upper page, het overzicht => alle data uitspuwen)
				$table 	= $this->overviewPage();		// get users from database in tableform
				//$button = $this->addButton("/create", "Solliciteren");	// add "/add" button. This is ACTION button
				// first show button, then table
                $html = "";
                //$html .= $button ."<br />";
				$html .= $table;
				return $html;
			}
		}

		// show button with the PAGE $p_sAction and the tekst $p_sActionText
        // deze button volgt gewoon een link => geen NAME nodig, enkel een URL
		private function addButton($p_sAction, $p_sActionText) {
			// calculate url and trim all parameters [0..9]
            $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
			// create new link with PARAM for processing in new page request
			$url = $url . $p_sAction;
			$button = "<button style='margin-top: 10px;' onclick='location.href = \"$url\";'>$p_sActionText</button>";
			return $button;
		}

            
		// deze functie geeft de overview page weer (als er géén ACTIOn in de URL staat)
		private function overviewPage(){
			// execute a query and return the result
            
			$sql='SELECT * FROM `tb_vacature` ORDER BY vacature';
            $result = $this->createTable(Database::getData($sql));

			//TODO: generate JSON output like this for webservices in future
			/*
				$data = Database::getData($sql);
				$json = Database::jsonParse($data);
				$array = Database::jsonParse($json);

				echo "<br />result: ";  print_r(Database::getData($sql));
	            echo "<br /><br />json :" . $json;
	            echo "<br /><br />array :"; print_r($array);
			*/

			return $result;
		} // end function getData()

		private function createTable($p_aDbResult){ // create html table from dbase result
			$image = "<img src='".ICONS_PATH."noun_information user_24px.png' />";
			$table = "<table border='1'>";
				$table .= "	<th>uuid</th>
							<th>vacature</th>
							<th>bekijk</th>";
				// now process every row in the $dbResult array and convert into table
				foreach ($p_aDbResult as $row){
					$table .= "<tr>";
						foreach ($row as $col) {
							$table .= "<td>" . $col . "</td>";
						}
	                    // calculate url and trim all parameters [0..9]
	                    $url = rtrim($_SERVER['REQUEST_URI'],"/[0..9]");
						// create new link with parameter (== edit user link!)
						$table 	.= "<td><a href="
								. $url 							// current menu
								. "/detail-vacature/" . $row["id"] 	// add ACTION and PARAM to the link
								. ">$image</a></td>";			// link to edit icon
					$table .= "</tr>";
					
				} // foreach
			$table .= "</table>";
			return $table;
            
		} //function

	   private function aanmaken(){
           
       }
            
		// als URL ACTION gelijk is aan detail-vacature
		private function detailVacature() {
			
            // URL = Uniform Resource Locator
            // Uniform = uniform -> gestandaardiseerd, voor iedereen hetzelfde, een vast formaat
            // Resource = grondstof of een element
            // Locator = locatie die vastgelegd wordt
            // variabele $id haalt het ID uit de adresbalk (of URL) aan de hand van "PARAM"-constante
            $id = PARAM;
            
            // variabele met de "Terugknop" => deze gaat eerst 2 niveaus omhoog (1 niveau per "../") zodat we op de "home" zitten, en dan vervolgens gaan we wel terug naar "vacature".
            $buttonBack = $this->addButton("/../../vacature", "Terug");	
            
            
            // http://localhost/buurtzorg24/vacature/detail-vacature/3
            // variabele met de knop "Solliciteer" om naar een nieuwe pagina te gaan, waarop het sollicitatieformulier staat
			$buttonSolliciteren = $this->addButton("/../../vacature/sollicitatie/$id", "Solliciteer");	
			
            // query om specifiek de details van één ID te raadplegen: we gaan in de database spécifiek het ID oproepen, dat ook meegegeven is in de adresbalk ($id, aan de hand van PARAM hierboven).
            $sql="SELECT * FROM `tb_vacature` WHERE id = '".$id ."'";
            
            // resultaat weergeven a.d.h.v. de variabele / query $sql
            $result = $this->createTable(Database::getDATA($sql));
            
            // de uiteindelijke HTML weergeven op het scherm
            return $buttonBack ."<br/>" . $result ."<br/>". $buttonSolliciteren;
            
                   
		} 
            
		// show button with the PAGE $p_sAction and the tekst $p_sActionText
		private function addTextfield($p_name, $p_placeholder) {
			// calculate url and trim all parameters [0..9]
            $textfield = '<input style="margin-top: 10px;" type="text" name="'. $p_name .'" placeholder="'. $p_placeholder .'" />';
			return $textfield;
		}

            
		// show button with the PAGE $p_sAction and the tekst $p_sActionText
		private function addBigTextfield($p_name, $p_placeholder) {
			// calculate url and trim all parameters [0..9]
            $textarea = '<textarea style="margin-top: 10px; width: 400px;height:200px;" name="'. $p_name .'" placeholder="'. $p_placeholder .'"></textarea>';
			return $textarea;
		}

        
        // formulierbutton is anders dan gewone button: gewone button volgt een link, formulierbutton moet een formulier "submitten"
        // om een formulier in te drukken, hebben we een button NAME nodig (deze wordt doorgegeven met "POST")
		private function addFormulierButton($p_buttonName, $p_buttonText) {
			$button = "<button name='".$p_buttonName."'>$p_buttonText</button>";
			return $button;
		}
	
		// deze functie geeft de pagina weer om te solliciteren op basis van de URL, ACTION = "sollicitatie"
		private function sollicitatieFormulier() {
			// backbutton
            $backButton = $this->addButton("/../../vacature", "Terug");	
			
            // tekstveld naam
            $textNaam = $this->addTextfield ("naam", "Volledige naam");
            
            // tekstveld e-mail
            $textEmail = $this->addTextfield ("email", "Volledige Email");
            
            // groot tekstveld voor de motivatie
            $textMotivation = $this->addBigTextfield ("motivatie", "Motivatiebrief");
            
            // verzendknop met een "name" en een "knoptekst"
            $buttonSend = $this->addFormulierButton("solliciteerKnop", "Sollicitatie Verzenden");
            
            // WE GAAN HET FORMULIER OP DEZE PAGINA VERWERKEN, DUS DAN MOET ER OOK EFFECTIEF EEN VERWERKEND STUK ZIJN
            // hiermee checken we of er effectief op de knop werd gedrukt:
            if ( isset ( $_POST['solliciteerKnop'] ) ) {
                $vacatureId = PARAM;
                $sql="SELECT * FROM `tb_vacature` WHERE id = '".$vacatureId ."'";
                $result = Database::getDATA($sql);
                
                // er werd nu op de knop gedrukt, dus moeten we een mail sturen
                $to = "dirk.have208630@student.leeuwenborgh.nl";
                $subject = "Sollicitatie voor vacature '".$result[0]['vacature']."'";
                $message = "Er werd gesolliciteerd door ". $_POST['naam'] ." met e-mailadres ". $_POST['email'] ."\n\n\n". $_POST['motivatie'];
                
                $textNaam       = $_POST['naam'];  
                $textEmail      = $_POST['email'];
                $textMotivation = $_POST['motivatie'];
                
                //mail($to,$subject,$message);
                $sql = "INSERT INTO 
                    `tb_sollicitanten` 
                    (`id`, `vacature_id`, `volledigenaam`, `Email`, `bericht`, `status`) 
                VALUES 
                    ('NULL','$vacatureId', '$textNaam', '$textEmail', '$textMotivation','0')";
                Database::getData($sql);
                header("location: ../../goedkeuring");
                
            } else {
                
                echo 'er werd nog niét gedrukt, dus we gaan ook niet verwerken';
                
            }
            
            
            // we hebben een formulier, dat we verwerken met post
            // als er gepost wordt, wordt deze verwerkt op de pagina, die opgegeven wordt bij "action"
            // de pagina is in dit geval de eigen, zelfde pagina
            // die eigen zelfde pagina roepen we simpelweg op met $_SERVER['REQUEST_URI']
            return "vb. Request_URI: ". $_SERVER['REQUEST_URI'] ."
            
            <p>".$backButton ."</p>
            
            <form method='post' action='". $_SERVER['REQUEST_URI'] ."'>
                <p>". $textNaam ."</p>
                <p>". $textEmail ."</p>
                <p>". $textMotivation ."</p>
                <p>". $buttonSend ."</p>
            </form>";
            
                   
		} // function details

	}// class gebruikerPage
?>    
	